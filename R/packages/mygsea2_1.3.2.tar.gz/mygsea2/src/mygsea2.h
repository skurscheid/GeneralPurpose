
typedef struct {
  double pos_score;
  double neg_score;
} resKS;


typedef struct {
  double pval_pos;
  double pval_neg;
} resPerm;
