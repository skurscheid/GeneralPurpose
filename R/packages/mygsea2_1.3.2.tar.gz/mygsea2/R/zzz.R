.First.lib <- function(lib, pkg) {
  library.dynam("mygsea2",pkg,lib)
}
